JS-Interpreter
==============

A sandboxed JavaScript interpreter in JavaScript.  Execute arbitrary JavaScript
code line by line in isolation and safety.

Live demo:
https://neil.fraser.name/software/JS-Interpreter/

Documentation:
https://neil.fraser.name/software/JS-Interpreter/docs.html
